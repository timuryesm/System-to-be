package SystemToBe;

public interface Command {
	void execute();
}
