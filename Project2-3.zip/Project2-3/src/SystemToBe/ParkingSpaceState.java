package SystemToBe;

public interface ParkingSpaceState {
	void book(ParkingSpace space);
    void cancel(ParkingSpace space);
}