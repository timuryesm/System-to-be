package SystemToBe;



/**
 *
 * @author 
 */
public interface Sensor{
	
	 void update(Observer observer);
	
}
