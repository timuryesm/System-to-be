package SystemToBe;


/**
 *
 * @author
 */
public class creditCard extends Payment {

}
